package com.Entity;

public enum ERole {
  ROLE_PATIENT,
  ROLE_OPERATOR
}
